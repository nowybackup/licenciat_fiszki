<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/css/fontello.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/cms.css">


    <script src="jquery.min.js"></script>
    
</head>
