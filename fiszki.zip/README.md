# licenciat_fiszki
Wersja aplikacji z odzielonym panelem administracyjnym, jednak pewne wyjątki są nierozpisane i potrafią pojawiać się błędy
1. Ta wersja obejmuje możliwość zarządzania wieloma zestawami i ich edycje po przez dodanie nowych słówek, ich aktualizacje, lub usunięcie
2. Panel nauki, który losuje słówka  i odtwarza fonetyczną wymowę słowa pobierając nagranie z serweru diki
